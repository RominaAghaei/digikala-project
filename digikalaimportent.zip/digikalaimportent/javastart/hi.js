function myage(ageyear) {
  return 2025 - ageyear;
}
const age = myage(2005);
